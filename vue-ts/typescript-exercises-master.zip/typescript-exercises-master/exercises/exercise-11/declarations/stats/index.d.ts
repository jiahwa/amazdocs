declare module 'stats' {
    export function getMaxIndex(input: unknown, comparator: unknown): unknown;
}
